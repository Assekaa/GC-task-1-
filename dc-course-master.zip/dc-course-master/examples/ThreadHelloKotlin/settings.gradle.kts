
rootProject.name = "ThreadHelloKotlin"

