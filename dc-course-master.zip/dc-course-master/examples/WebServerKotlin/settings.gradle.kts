
rootProject.name = "WebServerKotlin"

